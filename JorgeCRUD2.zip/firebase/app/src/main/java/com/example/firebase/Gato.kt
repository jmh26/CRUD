package com.example.firebase


import android.net.Uri
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.io.Serializable
import java.util.Date

@Parcelize
data class Gato(
    var id : String? = null,
    var raza: String? = null,
    var descripcion: String? = null,
    var edad: Int? = null,
    var calificacion: Int? = null,
    var fecha: Date? = null,
    var imagen: String? = null

):Parcelable