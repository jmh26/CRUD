package com.example.firebase

class Estado {

    companion object{
        const val notificado = 0
        const val creado = 1
        const val modificado = 2

    }

}